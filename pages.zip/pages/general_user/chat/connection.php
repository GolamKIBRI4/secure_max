<?php
	$conn=mysqli_connect("localhost","root","","uiuservicehub");
	date_default_timezone_set('Asia/Dhaka');
?>