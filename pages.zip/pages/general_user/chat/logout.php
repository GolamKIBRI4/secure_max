<?php
	include '../../sqlCommands/connectDb.php';
	session_start();
	
?>