<?php
    session_start();
    session_destroy();

    header("location: ../../../../uiu1");
    exit();
?>